# Power BI Starter Package

Power BI Desktop is required to save a true `.pbix` file.

Use these files:

- `cms_provider_services_dashboard_ready.csv`
- `PowerBI_DAX_Measures.txt`
- `PowerBI_PowerQuery_CMS_Provider_Services.m`
- `PowerBI_Report_Layout_Blueprint.json`

Dataset source: https://catalog.data.gov/dataset/provider-of-services-file-hospital-non-hospital-facilities

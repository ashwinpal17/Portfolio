// Load this query in Power BI Desktop.
let
    Source = Csv.Document(File.Contents("cms_provider_services_dashboard_ready.csv"),[Delimiter=",", Encoding=65001, QuoteStyle=QuoteStyle.Csv]),
    PromotedHeaders = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),
    ChangedTypes = Table.TransformColumnTypes(PromotedHeaders,{
        {"Provider Number", type text},
        {"Facility Name", type text},
        {"State", type text},
        {"City", type text},
        {"Zip Code", Int64.Type},
        {"Region", type text},
        {"Facility Category Code", type text},
        {"Facility Category", type text},
        {"Ownership Code", type text},
        {"Ownership Type", type text},
        {"Compliance Status Code", type text},
        {"Compliance Status", type text},
        {"Eligible", type text},
        {"Acceptable Plan of Correction", type text},
        {"Certification Date", type date},
        {"Original Participation Date", type date},
        {"Termination Date", type date},
        {"Bed Count", Int64.Type},
        {"Has Termination Date", type logical},
        {"Certification Year", Int64.Type}
    })
in
    ChangedTypes